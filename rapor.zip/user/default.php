<?php require_once('/index.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Nilai Akademik</title>

    <!-- Bootstrap Core CSS -->
    <link href="user/css/bootstrap.min.css" rel="stylesheet">
    <link href="user/css/bootstrap-theme.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="user/css/clean-blog.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Nilai Akademik SKARIGA</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Header -->
    <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('user/img/skola.gif')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="site-heading">
                        <h1>SMK PGRI 3 Malang</h1>
                        <hr class="small">
                        <span class="subheading">Portal Nilai Akademik</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                <div class = "jumbotron">
                    <h1>Selamat Datang</h1>
                    <p>Portal Nilai Akademik Siswa Khusus untuk Departemen Teknik Informartika SMK PGRI 3 Malang.</p>
                    <a class="btn btn-primary btn-lg"  href = "?url=login" role="button"><span class="glyphicon glyphicon-user"></span> Login</a>
                </div>
            </div>
        </div>
    </div>
<!--
     <div id="mymodal" class="modal fade" >
        <div class="modal-dialog" >
            <div class="modal-content" style="margin-left:200px;width:300px;margin-top:100px;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Silahkan Login</h4>
                </div>
                <div class="modal-body">
                   <form class="form-inline" action="login2.php" method="post" role="form">
    <div class="form-group">
        <label class="sr-only" for="inputEmail">Username</label>
        <input type="text" class="form-control" placeholder="Username" name="username">
    </div><br><br>

    <div class="form-group">
        <label class="sr-only" for="inputPassword">Password</label>
        <input type="password" class="form-control" placeholder="Password" name="password">
    </div> <br> <br>
                    <div class="modal-footer">
                            <input type="submit" name="submit" value="Submit" class="btn btn-success">
                        </form>  
                    </div>
                </div>
            </div>
        </div>
    </div>-->

    <hr>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <ul class="list-inline text-center">
                        <li>
                            <a href="#">
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-github fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                    </ul>
                    <p class="copyright text-muted">Copyright &copy; Sovira Fitra Aulia 3RPA 2015</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="user/js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="user/js/bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="user/js/clean-blog.min.js"></script>

</body>

</html>
