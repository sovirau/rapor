
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2015 Sovira Fitra Aulia 3RPA</a>
                </div>

            </div>
        </div>
    </footer>