<script type="text/javascript">window.print();</script>
<html>
<head><title>Nilai Akademik</title></head>
<body>
<table width="595" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="1259" height="842"><center>SMK PGRI 3 Malang</center>
      </p>
      <table width="511" height="95" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="98" height="38"><span class="SATU">Nama</span></td>
          <td width="4"><span class="SATU">:</span></td>
          <td width="139"><span class="SATU">Alfian Prasetyo</span></td>
          <td width="145"><span class="SATU">Tahun Pelajaran</span></td>
          <td width="9">:</td>
          <td width="116"><span class="SATU">2013/2014</span></td>
        </tr>
        <tr>
          <td><span class="SATU">Nomor Induk</span></td>
          <td><span class="SATU">:</span></td>
          <td><span class="SATU">65373</span></td>
          <td><span class="SATU">Semester</span></td>
          <td>:</td>
          <td><span class="SATU">I (Satu)</span></td>
        </tr>
        <tr>
          <td><span class="SATU">Kelas</span></td>
          <td><span class="SATU">:</span></td>
          <td><span class="SATU">XII RPL B</span></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <br>
      <br />
      <table width="595" height="337" border="1" align="center" cellpadding="0" cellspacing="0">
        <tr class="font--nilai--bold">
          <td width="31" align="center"><span class="font--nilai1">No</span></td>
          <td width="462" align="center"><span class="font--nilai1">Mata Pelajaran</span></td>
          <td width="65" align="center"><span class="font--nilai1">KKM</span></td>
          <td width="62" align="center"><span class="font--nilai1">Nilai</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">1</span></td>
          <td align="center"><span class="font--nilai1">Pendidikan Agama</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">85.3</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">2</span></td>
          <td align="center"><span class="font--nilai1">Bahasa Indonesia</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">87</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">3</span></td>
          <td align="center"><span class="font--nilai1">Bahasa Inggris</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">89.3</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">4</span></td>
          <td align="center"><span class="font--nilai1">Matematika</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">5</span></td>
          <td align="center"><span class="font--nilai1">Fisika</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">8.2</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">6</span></td>
          <td align="center"><span class="font--nilai1">Kimia</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">8.1</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">7</span></td>
          <td align="center"><span class="font--nilai1">Pendidikan Kewarganegaraan</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">7.8</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">8</span></td>
          <td align="center"><span class="font--nilai1">Web Desain</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">90</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">9</span></td>
          <td align="center"><span class="font--nilai1">Sistem Analisis</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">92.3</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">10</span></td>
          <td align="center"><span class="font--nilai1">Tekhnologi Informasi dan Komunikasi</span></td>
          <td align="center"><span class="font--nilai1">75</span></td>
          <td align="center"><span class="font--nilai1">98.3</span></td>
        </tr>
        <tr>
          <td colspan="3" align="center"><span class="font--nilai1">Jumlah Nilai Rata-Rata</span></td>
          <td align="center"><span class="font--nilai1">86</span></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <table width="544" border="1" align="left" cellpadding="0" cellspacing="0">
        <tr class="head--table">
          <td width="22">No</td>
          <td width="289">Kegiatan Pengembangan Diri</td>
          <td width="67">Nilai</td>
          <td width="156">Keterangan</td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">1</span></td>
          <td align="center"><span class="font--nilai1">Sepak Bola</span></td>
          <td align="center"><span class="font--nilai1">A</span></td>
          <td align="center"><span class="font--nilai1">Sangat Baik</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">2</span></td>
          <td align="center"><span class="font--nilai1">Basket</span></td>
          <td align="center"><span class="font--nilai1">B</span></td>
          <td align="center"><span class="font--nilai1">Baik</span></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p><br />
        <br>
      </p>
      <table width="356" border="1" align="left" cellpadding="0" cellspacing="0">
        <tr class="head--table">
          <td colspan="2">Ahlak dan Kepribadian</td>
        </tr>
        <tr>
          <td width="195" align="center"><span class="font--nilai1">Ahlak</span></td>
          <td align="center"><span class="font--nilai1">A</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">Kepribadian</span></td>
          <td width="155" align="center"><span class="font--nilai1">B</span></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p><br />
        <br>
      </p>
      <table width="356" border="1" align="left" cellpadding="0" cellspacing="0">
        <tr class="head--table">
          <td colspan="2">Ketidak Hadiran</td>
        </tr>
        <tr>
          <td width="195" align="center"><span class="font--nilai1">Sakit</span></td>
          <td align="center"><span class="font--nilai1">1 Hari</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">Izin</span></td>
          <td width="155" align="center"><span class="font--nilai1">2 Hari</span></td>
        </tr>
        <tr>
          <td align="center"><span class="font--nilai1">Tanpa Keterangan</span></td>
          <td align="center"><span class="font--nilai1">* Hari</span></td>
        </tr>
      </table>
      <p>&nbsp; </p>
      <p>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
</table>
<p class="dua">&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<footer>Nilai Akademik</footer>
</body>
</html>
